# 40deploy
40k deployment trainer
